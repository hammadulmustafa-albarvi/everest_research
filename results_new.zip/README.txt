EVerest Security-RE Experiment — output manifest
=================================================

results_summary.csv
    Accuracy / precision / recall / F1 for every RQ x condition (9 rows).
    RQ1 also includes objective_accuracy (5-way: confidentiality/integrity/
    availability/authentication/other). RQ1's precision is always 1.0 and
    accuracy equals recall — see section 11 for why (no negative class exists
    in this dataset's 93 requirements).

confusion_matrices.csv
    TP/FP/TN/FN for all 6 RQ1/RQ2 conditions. RQ1 rows always show TN=FP=0
    (same reason as above). confusion_matrices/*.png are the same data as images.

statistical_tests.csv
    McNemar's test (RQ2) / Wilcoxon signed-rank (RQ3) p-values comparing every
    pair of conditions. RQ1 has no paired significance test (no negative class
    to pair on) — its numbers in results_summary.csv are the full result.

predictions/RQ{1,2,3}_{zero_shot,few_shot,rag}.csv
    Every individual model prediction, one row per requirement, with the true
    label alongside it. This is what results_summary.csv and
    confusion_matrices.csv were computed from — nothing is only-in-summary.

Data / method notes
    - All 93 requirements evaluated for RQ1/RQ2 (all 58 with a trace-link
      annotation for RQ3) — nothing held out from testing.
    - 10 requirements are used as few-shot examples (EXAMPLE_IDS in the
      notebook, section 6) — chosen to cover every security objective and
      both requirement_label values. Zero-leakage is verified in section 8:
      an item is always excluded from its own example list.
    - Model: Qwen/Qwen2.5-7B-Instruct, temperature 0 (greedy decoding), run locally.
