package org.everest.model;

import org.eclipse.core.runtime.Plugin;

public class Activator extends Plugin {
}
