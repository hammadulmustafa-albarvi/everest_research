# Annotation Guideline

All labels (except the labels `requirement`) were assigned in an inter-annotator agreement. 
During their discussions, the annotators refined the guideline and updated labels that were already done accordingly.

## Annotations

According to the discussions during the inter-annotator discussions, the guideline and definition were adapted and made more precisely and explicit. 
The annotators also decided for the fields that were labeled and their definition. 
In general, *long sequences*, *short sequences*, *coreferences*, and *references* were labeled.

>**long Sequences:** longest acceptable sequence
>	* includes further descriptions of the core information
>	* includes articles
>	* x times if it should be mentioned x times

>**short Sequences:** required information for acceptance
>	* explicitly mentioned contents, e.g. "MeterValues.req"
>	* terms as short as possible but expressive enough to understand their meaning (if specified in the text), e.g., "independent state machines", "malformed input", 
>	* compared word by word but not necessarily in order, e.g., "Tokens used for authentication" expected words: "Tokens", "authentication". If this applies to a sequence, write a comment with a tuple of the sequence to be exchanged and the expected words: "(Tokens used for authentication, Tokens authentication)"
>	* in some cases examples are given. E.g. "information about the user [...]: authentication token, [...]". In those cases the broad term is acceptable but not necessary. In these cases create a comment with: "optional: [sequence]". In combination with word comparison do two separate comments and enter the expected words as optionally expected
>	* for patterns like "Abbreviation (Name)" only the abbreviation is required

>**Coreferences:**
>	* formulation/ term that refers to an instance that was mentioned before

>**References:**
>	* formulation/ term that refers to (a set of) a not closer described instance
>   * cannot be traced without further knowledge


## Original guideline

The following is an excerpt of the definitions of SecLan [1].

| Element | Definition |
| --- | --- |
| Data | Collection of values that convey information. |
| State | The state of an Activity or Entity that might be represented by Data. |
| Activity | An action that is executed by a specific Entity that can process Data and communicate with other Activities. Activities can be realized as well by manual actions of actors in a system such as the user, be described in behavioral models, or implemented in functions at the source code level. |
| Entity | A physical actor or software object of a specific type that can hold Data and might have a State. |
| Component | A part of software that potentially comprises one or multiple Entities and can be deployed individually on a Node. |
| Node | A physical device on which software is executed that can be connected with other nodes over Connections. |
| Connection | A physical connection between Nodes over which information can be communicated (Information Flow). Thereby, the connection is not limited to connections between nodes but might also be an internal connection within a node such as a local socket. |
| Information Flow | The communication of Data between Activities or Entities either over a Connection or internally within a program. |
| Control Flow | The orchestration of Activities in terms of the execution of one Activity leading to the execution of another Activity. (Could an Entity be the controlling part of a control flow?) |

[1] Sven Peldszus, Frederik Reiche, Kevin Hermann, Sophie Corallo, Thorsten Berger, and Robert Heinrich. 2026. Can I Check What I Designed? Mapping Security Design DSLs to Code Analyzers. arXiv:2605.07814 [cs.CR]


## Requirements: 

>**Annotations**
>* text: the text of the requirement
>* security_objective: the security objective under which the coarse-grained requirement was defined
>* author: the author of the requirement (PIONIX developer or Bytecharge developer)
>* origin_id: the id of its coarse-grained requirement
>* id: its own id
>* security_confidence: the authors confidence regarding security
>* requirement_label: whether the provided text is a requirement or not. Criteria: A text that describes a current state is not labeled as requirement. \*
>* security_label: whether this is actual a security-related text or not

\* Please note that even though all texts in the requriements folder were elicited as requirements, were elicited as requirements. However, for some texts, two later annotators agreed that these are rather general descriptions of the software than actual requirements. Thus, for some the requirment label is actually false.

## Components: 

> **Definition**
>
> Component: A part of software that potentially comprises one or multiple entities and can be deployed individually on a node
>	* database
>	* architectural layers
>	* subsystems
>	* frameworks

>**Annotations:**
>* short sequence: smallest part of the noun phrase that allows to identify a component
>* long sequence: complete noun phrase mentioning the component
>* references: noun phrases mentioning components without naming them, the system name
>* coreferences: coreferences or interchangeable names of components mentioned in the text; must refer to references or short sequences of components

**Additional Comments**:
* implicit references, e.g. to the OCPP protocol are not mapped directly to the respective components (e.g. in req 31)
* if components were not mentioned intentionally, the mentioning is marked as reference
* reference also if multiple components are meant without specifically mentioning their names
* left outs are marked with <...>
* if multiple components are mentioned under a common name and their specific name is given in the text, only the specific mentions are traced/ marked as components
* only system-internal components were annotated; external components/ systems are not marked (e.g. MQTT broker, trusted platform module, CSMS)
* if protocols were mentioned as such, they were not marked
* libraries are not components and do not reference to such , e.g., libocpp and libevse libraries
* if a module was mentioned but only their interfaces contained in the architecture, they were annotated like components (e.g. ISO15118 module or AuthTokenProvider)
* payment provider was represented as an external component mocked in EVerest and thus marked as a component

## Data:
> **Definition**
>
> Data: a collection of values that conveys information
>	* attributes of a class
>	* parameters
>	* composed data objects, e.g., personal data, address, credit card information
>	* certificates


>**Annotations:**
>* short sequence: smallest part of the noun phrase that allows to identify a component
>* long sequence: complete noun phrase mentioning the data
>* references: noun phrases mentioning data without naming them
>* coreferences: coreferences or interchangeable names of data mentioned in the text; must refer to references or short sequences of data


**Additional Comments**
* short sequences contain only necessary terms and order is ignored

## Dataflows: 

> **Definition**
>
> Information Flow: The communication of data between activities or entities either over a connection or internally within a program.
>	* storing/ persisting is no dataflow (except if it is in another component)
>	* entity/ component transmits data
>	* timewise information are accepted in long phrase
>	-> required: entity/ component [transmission word] data [to entity/ component] (if mentioned in the requirement)
>	-> change to dataflow as information flow = activity

>**Annotations**
>* source: source of the dataflow; the source is either a component, entity, or node
>* target: sink of the dataflow; the sink is either a component, entity, or node
>* transmission: the verb that describes how the data is transmitted from source to sink
>* data: data that is transmitted in the dataflow; this should be classified as data
>* references: phrases that describe a dataflow, but mention neither source nor sink
>* coreferences: coreferences on dataflows

**Additional Comments**:
* dataflows are characterized by a unique source and a unique target
* just access control information are not labeled as dataflows
* at least one kind of data must be mentioned
* negations of the transmission are labeled in the transmission field itself.

## Entities:
> **Definition**
> 
> Entity: A physical actor or software object of a specific type that can hold data and might have a state
>	* users
>	* libraries/ protocols
>   * log files/ config files


> **Annotations**
>* short sequence: smallest part of the noun phrase that allows to identify an entity 
>* long sequence: complete noun phrase mentioning the entity
>* references: noun phrases mentioning entities without naming them
>* coreferences: coreferences or interchangeable names of entities mentioned in the text; must refer to references or short sequences of entities

**Additional Comments**
* Entities are externals, libraries, protocols, physical actors, or systems that can held states, and interfaces
* "[component name] interface" were marked as both, reference for the interface as well as reference to the component

### Control Flows: 
>**Definition**
>
> Control Flow: The orchestration of activities in terms of the execution of one activity leading to the execution of another activity.

>**Annotations**
>* action: action verb of the controlflow
>* source: initiator of the controlflow; can either be a component, node or entity
>* target: recipient of the controlflow; can either be a component, node or entity
>* references: phrases that contain controlflow but neither explicitly mention a source nor a target
>* coreferences: coreferences on controlflows

**Additional Comments**
* "if X happens Y has to be done" is currently not reflected in the goldstandard - only if there's a direct relation
* differentiation to connection: Connections are outside of the system boundaries (not so easy - persons are also out of system boundaries -> moving to connections?)

## States: 

> **Definition**
>
> State: the state of activity, data, entity, node, or the system as is that might be represented by data
>	* securely stored personal information
>	* configurations/ execution profiles
>	* crashed server

>**Annotations**
>* state: part of the phrase that contains a state, role, restriction, or addition to a state object
>* object: owner/holder of the state. The object is either the short sequence/ included in a reference of a data, entity, component, node, connection, dataflow, activity, or must be mentioned in a state 
>* negation: part of the phrase that indicates a negation of the state
>* references: phrases mentioning states without a mentioned object
>* coreferences: coreferences of states

**Additional Comments**
* "States are attributes of an object or the roles assigned to an adversary" thus:  states are states or roles of data, entities, components, nodes, states, or properties of such, or are describing the attributes or circumstances of the object in more depth
* states can limit or restrict certain parts of data, entities, activities, etc., thus, limitations, precisions of data are considered as states. This includes statements about the purpose of such things.
* statements describing the software design  as such or the relation to standards, like OCPP, ISO norms, etc. are not labeled as states (A implements B, C is included in the process D, E is defined in F)
* States can be nominalized (stability id12)
* States are a reference if the object is unknown/ not explicitly mentioned.
* states include statements about the existence/ absence of things
* states include statements about compliance or fulfillment of requirements
* states are currently described in different granularity
* note that states and activities are not completely exclusively defined

## Activities: 
>**Definition**
>
> Activity: an action that is executed by an entity that can process data and communicate with other activities
>	* manual actions of actors
>	* described functions
>	* updates

>**Annotations**
>* actor: performer of the activity. The activity is either the short sequence/ reference of a component, entity, or node.
>* activity: verb that indicates an activity, can also be a state
>* objects: objects that are used in the activity. An object can be anything.
>* negation: part of the phrase that indicates a negation of the state
>* additives: phrase with additional information about the circumstances of the activity
>* references: phrases mentioning activities without naming them
>* coreferences: coreferences of activities

**Additional Comments**

* activities include statements about the realization & implementation (X is a database),  as well as ownerships of data/ entities.
* note that states and activities are not completely exclusively defined


## Connections:
> **Definition:**
>
> Connection: A physical connection between nodes over which information can be communicated (Information Flow). 
Thereby, the connection is not limited to connections between nodes but might also be an internal connection within a node such as a local socket.


>**Annotations**
>* source: a node, entity, or component that is physically connected; if specified the source is the initiator of the connection
>* target: a node, entity, or component that is physically connected; if specified the source is the recipient of the connection
>* via: connector over that the physical source and target are linked

## Nodes: 
> **Definition**
>
> Node: a physical device on which software is executed that can be connected with other nodes over connections


>**Annotations**
>* short sequence: smallest part of the noun phrase that allows to identify a node
>* long sequence: complete noun phrase mentioning the node
>* references: noun phrases mentioning nodes without naming them
>* coreferences: coreferences or interchangeable names of nodes mentioned in the text; must refer to references or short sequences of nodes

**Additional Comments**
* websockets, ports, and backend layers are labeled as nodes








